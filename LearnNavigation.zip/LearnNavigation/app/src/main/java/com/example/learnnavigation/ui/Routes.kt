package com.example.learnnavigation.ui

object Routes {
    var ScreenA = "Screen_A"
    var ScreenB = "Screen_B"
    var ScreenC = "Screen_C"
}